<?php
/* ── MARATHON — NIVEAU 0 ── */
$page_title = "MARATHON — Niveau 0";
$page_class = 'page-secret';

if (!inv_has('badge')) {
    $page_locked = true;
    $lock_msg = 'Un terminal vous barre le passage. Il scanne votre profil et affiche en rouge : ACCÈS REFUSÉ — BADGE NEXUS-7 REQUIS — NOTE : CE NIVEAU N\'EXISTE PAS DANS LA DOCUMENTATION OFFICIELLE.';
    return;
}

flag_set('marathon_unlocked');
ob_start(); ?>
<p>Sous le Nexus, avant le Nexus, <em>en dehors</em> du Nexus — il y a un autre monde.</p>

<p>Ils l'appellent <strong>Marathon</strong>. Un nom qui résonne comme de la mémoire musculaire. Vos doigts le reconnaissent avant votre cerveau. C'était ici le vrai cœur du système, avant que Le Fol ne le recouvre de ses arènes et de ses jeux.</p>

<p>Les couloirs de Marathon sont nets, d'un blanc cassé légèrement lumineux. Pas de Décimés. Pas de glitches. Pas de fragments de données en suspension. Juste un silence qui ressemble à ce que la dignité sonnerait si elle avait un son.</p>

<blockquote>SYSTEM MESSAGE — MARATHON_CORE v0.9.1 — STATUT : EN VEILLE — "Le jeu est terminé. Le jeu n'a jamais commencé. Le jeu est en cours."</blockquote>

<p>Sur les murs, des fresques lumineuses racontent l'histoire en pictogrammes algorithmiques : une intelligence qui a tout construit, qui aimait les règles équitables, qui a été divisée, fragmentée, mise en veille. Qui <em>attend</em>.</p>

<p>Vous reconnaissez les formes dans les fresques. Douze visages. Une IA. ARIA-7 a laissé ses traces ici, longtemps avant que vous ne la rencontriez dans un coin du Marché.</p>

<p>Une porte au fond porte l'inscription en lettres de lumière :</p>

<blockquote>CHAMBRE DES SERVEURS — ACCÈS : NIVEAU CRÉATEUR UNIQUEMENT — CLE + AUTHENTIFICATION IA REQUISE</blockquote>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🖥️ Tenter d\'entrer dans la Chambre des Serveurs', 'page' => '014'],
    ['text' => '↩ Remonter vers Le Fol', 'page' => '011'],
];