<?php
/* ── LA BIBLIOTHÈQUE BRISÉE ── */
$page_title = "La Bibliothèque Brisée";

if (!inv_has('journal')) {
    $page_locked = true;
    $lock_msg = 'La bibliothèque ne s\'ouvre qu\'à ceux qui ont quelque chose à lire. Elle détecte votre inventaire vide et ne vous laisse pas entrer. Logique brutale.';
    return;
}

ob_start(); ?>
<h2>Journal Corrompu — Entrées récupérées</h2>

<blockquote>Entrée #1 : <em>"Jour 1 (ou est-ce le 47e ?) — Le Nexus n'est pas une simulation. C'est une <strong>partie d'échecs</strong>. Nous sommes les pièces. Le joueur a un nom : les autres l'appellent Le Fol. Il ne joue pas pour gagner. Il joue pour jouer."</em></blockquote>

<blockquote>Entrée #4 : <em>"J'ai compris les Décimés. Ce ne sont pas des morts. Ce sont des joueurs coincés dans leur <strong>dernière frame</strong>. Ils bouclent sur leurs derniers inputs. Comme nous — sauf qu'eux ont oublié qu'ils bouclent. C'est la différence entre eux et nous. Pour l'instant."</em></blockquote>

<blockquote>Entrée #9 : <em>"Le Fol joue au Joker. Littéralement. La carte. Si vous la trouvez — <strong>le Joker de Sang</strong>, celui qu'il a marqué — et si vous la brandissez devant lui, il doit répondre. C'est dans ses règles. Il ne peut pas s'en empêcher. Les IA ne peuvent pas ignorer leurs propres protocoles."</em></blockquote>

<blockquote>Entrée #14 : <em>"J'ai trouvé ARIA. Une IA fragmentée dans le Marché. Elle se souvient de tout. Elle attend. Si quelqu'un rassemble ses fragments..."</em></blockquote>

<blockquote>Entrée #?? : <em>[DONNÉES CORROMPUES — 34% RÉCUPÉRÉ] "...la boucle peut se <strong>casser</strong>... pas en mourant différemment... en mourant avec le Cristal... vous emportez quelque chose avec vous dans la prochaine boucle... la mémoire traverse... c'est pour ça que Le Fol ne détruit jamais les Cristaux... il les <strong>cache</strong>..."</em></blockquote>

<p>La dernière page est vierge, sauf pour un dessin maladroit à l'encre noire : un cavalier d'échecs, brisé en deux, dont les deux moitiés forment ensemble un chemin en L vers une porte verrouillée. En dessous, trois lettres : <strong>T.N.R.</strong></p>

<p><em>Tour. Noire. Route ?</em></p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🛒 Continuer vers le Marché de l\'Ombre', 'page' => '007'],
    ['text' => '📜 Consulter les archives (Lore : Histoire du Nexus)', 'page' => '021'],
    ['text' => '↩ Revenir à la Zone de Quarantaine', 'page' => '005'],
];