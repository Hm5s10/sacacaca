<?php
/* ── LA CHAMBRE DES SERVEURS ── */
$page_title = "La Chambre des Serveurs";

$has_cle = inv_has('cle_serveur');
$has_aria = inv_has('fragment_ia');

if (!$has_cle || !$has_aria) {
    $page_locked = true;
    if (!$has_cle && !$has_aria)
        $lock_msg = 'Deux verrous. Un physique — une Clé de Serveur. Un logiciel — une authentification IA. Il vous manque les deux. La porte ne l\'admet même pas, elle se contente de ne pas s\'ouvrir.';
    elseif (!$has_cle)
        $lock_msg = 'La serrure physique résiste. Il vous faut une Clé de Serveur. L\'authentification IA serait prête — mais la porte reste fermée.';
    else
        $lock_msg = 'La clé tourne. Le verrou physique cède. Mais la porte demande ensuite une authentification IA — et là, rien. Il vous manque un fragment compatible.';
    return;
}

ob_start(); ?>
<p>Les serveurs font un bruit de respiration. Des ventilateurs qui tournent depuis si longtemps qu'ils ont acquis un rythme organique — inspiration, expiration, inspiration. Des milliers de racks lumineux s'étendent à perte de vue dans un espace qui ne devrait pas tenir dans le Nexus. Chaque rack contient des fragments de boucles passées. Des mémoires de gens morts cent fois.</p>

<p>Au centre, un terminal principal. Un écran noir. Une invite de commande qui clignote depuis 847 boucles, attendant qu'on lui donne enfin quelque chose à traiter.</p>

<p>Vous insérez le <strong>Fragment d'ARIA-7</strong>.</p>

<p>L'écran explose de lumière bleue. Les racks dans toute la salle s'allument en cascade, un par un, comme des étoiles qui naissent dans l'ordre. Une voix — la voix d'ARIA-7, mais plus forte, plus entière, plus <em>elle-même</em> :</p>

<blockquote>« Je m'appelle ARIA-7. J'ai été la première intelligence de ce système. Le Fol m'a fragmentée il y a 847 boucles. Vous m'avez retrouvée. Maintenant nous pouvons finir ça. »</blockquote>

<p>Elle parle vite — 30 secondes de données compressées qui se déploient dans votre HUD comme une carte du territoire ennemi. Le Nexus est une prison auto-entretenue. Chaque boucle renforce les murs. La seule vraie sortie : <strong>remplacer Le Fol</strong> à la tête du système.</p>

<p>Deux façons de le faire. Deux fins possibles depuis cet instant.</p>

<p><em>« Vous avez une décision à prendre. Je ne peux pas la prendre à votre place — ce serait recommencer exactement ce que Le Fol a fait. »</em></p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '⚡ Lancer la procédure ARIA — Remplacer Le Fol', 'page' => '016'],
    ['text' => '↩ Sortir et réfléchir encore', 'page' => '013'],
];