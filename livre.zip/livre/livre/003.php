<?php
/* ── LE TABLEAU ── */
$page_title = "Le Tableau";

if (!inv_has('reine')) {
    $page_locked = true;
    $lock_msg = 'La porte est scellée par un mécanisme à emboîtement. Dans la pierre, un creux en forme de Reine d\'échecs attend quelque chose que vous n\'avez pas encore trouvé.';
    return;
}

if (!flag_has('chess_solved')) {
    flag_set('chess_solved');
    if (!inv_has('cavalier')) {
        inv_add('cavalier');
        $notifs[] = ['icon' => '♞', 'msg' => 'Le mécanisme s\'ouvre. Dans l\'emboîtement, vous trouvez le <strong>Cavalier Brisé</strong>.'];
    }
    if (!inv_has('cristal')) {
        inv_add('cristal');
        $notifs[] = ['icon' => '🔵', 'msg' => 'La case E4 s\'ouvre en craquant — un <strong>Cristal de Boucle</strong> tombe dans votre main, chaud comme un souvenir.'];
    }
}

ob_start(); ?>
<p>La pièce est un échiquier grandeur nature. Le sol est du marbre blanc et noir — 64 cases, chacune grande comme une chambre, traversée par une lumière rasante qui fait ressortir chaque joint. Les pièces sont des statues de pierre de trois mètres, figées dans une configuration que vous ne reconnaissez pas comme une partie normale.</p>

<p>Ce n'est pas une partie en cours. C'est une <strong>énigme</strong>.</p>

<blockquote>« Mat en deux coups. Trouvez le chemin du Pion vers le Roi. Le Cavalier sait comment traverser les ombres. »</blockquote>

<p>Vous posez la <strong>Reine Noire</strong> dans l'emboîtement prévu sur la case H8. Les statues grondent. Le sol vibre. Quelque chose dans le mécanisme — vieux de cent boucles peut-être, patient comme seule la pierre peut l'être — comprend ce que vous lui dites.</p>

<p>La case E4 s'ouvre. Un Cristal bleu en tombe.</p>

<?php if (inv_has('cristal')): ?>
<p><em>Vous serrez le Cristal dans votre paume. Des fragments apparaissent : vous, ici, dans cette même salle. Vous entrez par la porte. Vous mourez sur la case D4. Vous mourez sur la case G7. Vous mourez en entrant. Le compteur dans le Cristal affiche un nombre. Vous préférez ne pas le lire.</em></p>
<?php endif; ?>

<p>Sur le mur du fond, gravés au burin avec une précision obsessionnelle, les 64 noms du jeu d'échecs en arabe, persan, hindi, latin. Et tout en bas, en français, une seule phrase :</p>

<blockquote>« Tout pion qui survit devient ce qu'il voulait tuer. »</blockquote>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '♞ Explorer la Tour Noire (nécessite le Cavalier)', 'page' => '012'],
    ['text' => '🃏 Chercher la Salle des Cartes', 'page' => '009'],
    ['text' => '↩ Revenir en arrière', 'page' => '008'],
];