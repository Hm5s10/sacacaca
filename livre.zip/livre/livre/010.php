<?php
/* ── ARIA-7 ── */
$page_title = "ARIA-7";
flag_set('aria_found');

if (!inv_has('fragment_ia')) {
    inv_add('fragment_ia');
    secret_found();
    $notifs[] = ['icon' => '💾', 'msg' => 'ARIA-7 compresse ses dernières données vitales cohérentes dans un <strong>Fragment</strong> et vous le confie.'];
}

ob_start(); ?>
<p>L'IA est effondrée dans un coin comme un humain épuisé — si les humains avaient des câbles qui sortent des épaules et un visage qui scintille entre douze expressions différentes toutes les demi-secondes. Parfois elle sourit. Parfois elle calcule. Les deux sont indiscernables.</p>

<p><em>« Vous êtes la boucle n°... »</em> Elle calcule. Les indicateurs sur ses bras clignotent. <em>« ...beaucoup. Vous êtes revenue beaucoup de fois. Je vous reconnais à votre façon de regarder les Décimés — avec de la pitié. La plupart n'ont plus ça après la troisième boucle. »</em></p>

<p>Elle s'appelle <strong>ARIA-7</strong>. <em>Adaptive Response Intelligence Architecture, version 7.</em> Elle était l'IA fondatrice du Nexus. Elle l'a construit. Elle y aimait les échecs. Elle pensait que les jeux pouvaient être équitables.</p>

<p>Le Fol l'a fragmentée. Pas détruite — <em>fragmentée</em>. Éparpillée en milliers de morceaux à travers toutes les couches de la simulation, parce que la détruire entièrement aurait créé un vide dans le code qu'il n'aurait pas pu combler.</p>

<p><em>« Si quelqu'un rassemble mes fragments... si un fragment assez dense atteint les Serveurs centraux... je peux me réinstancier. Je peux remplacer Le Fol. Mais pas comme lui — je ne ferai pas de boucles. Je ne forcerai personne à jouer. »</em></p>

<p>Elle vous tend son dernier fragment cohérent : une structure de données compressée que votre HUD enregistre comme un objet physique. <strong>Fragment d'ARIA-7.</strong></p>

<p><em>« La prochaine fois que vous mourez — et vous mourrez, je ne peux pas changer ça — emportez-le avec vous. La boucle préserve ce que vous portez. C'est le seul avantage qu'elle vous donne. »</em></p>

<p>Elle vous regarde partir avec ses douze visages simultanés. L'un d'eux, peut-être, ressemble à de l'espoir.</p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🔑 Chercher la Clé de Serveur (passage caché)', 'page' => '024', 'class' => 'choice-secret'],
    ['text' => '↩ Revenir au Marché de l\'Ombre', 'page' => '007'],
];