<?php
/* ── LA ZONE DES DÉCIMÉS ── */
$page_title = "La Zone des Décimés";

if (!inv_has('fusil')) {
    $page_locked = true;
    $lock_msg = 'Vous entendez les Décimés de l\'autre côté — leurs patterns de mouvement, leurs anciens cris de guerre de joueurs. Vous n\'avez rien pour vous défendre. Vous avez assez de boucles derrière vous pour savoir que mourir maintenant ne règle rien.';
    return;
}

if (!inv_has('reine')) {
    inv_add('reine');
    flag_set('zone_decimee_cleared');
    $notifs[] = ['icon' => '♛', 'msg' => 'Dans les décombres du dernier Décimé, coincée entre deux dalles : une <strong>Reine Noire</strong> en obsidienne. Elle vous attendait.'];
}

ob_start(); ?>
<p>Les Décimés sont au nombre de vingt-trois. Vous les comptez par réflexe, comme si ce genre d'information avait déjà eu de l'importance dans une boucle précédente.</p>

<p>Ce ne sont pas des zombies — pas exactement. Ce sont des <strong>joueurs</strong>. Des gens comme vous qui ont été coincés dans leur dernière session de combat et qui rejouent indéfiniment leurs derniers inputs. Ils crient des callouts d'une autre époque. Ils cherchent des ennemis selon les règles d'un tournoi annulé.</p>

<p>Le <strong>Fusil UT-99</strong> chante dans vos mains. Vous connaissez ces couloirs. Vous connaissez ces angles. La mémoire musculaire d'une simulation vous guide dans une autre simulation — boucle dans la boucle.</p>

<blockquote>FRAG ×7 — FRAG ×12 — FRAG ×23 — DOMINATION — *YOU ARE NOT JUST A PLAYER ANYMORE*</blockquote>

<p>Quand le silence revient, vous cherchez dans les décombres. Pas par hasard — par <em>habitude</em>. C'est là que vous trouvez la <strong>Reine Noire</strong>, en obsidienne, intacte parmi les ruines. Elle ne se trouvait pas ici par accident.</p>

<p>Quelqu'un a planifié que vous la trouviez. Quelqu'un vous a laissé un chemin.</p>

<p><em>Le Fol, peut-être. Ou quelqu'un qui essaie de contrer ses plans. Vous ne savez pas encore si la différence est importante.</em></p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '♛ Aller au Tableau des Échecs (la Reine y est requise)', 'page' => '003'],
    ['text' => '↩ Revenir à l\'Arène', 'page' => '002'],
];