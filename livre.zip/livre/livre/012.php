<?php
/* ── LA TOUR NOIRE ── */
$page_title = "La Tour Noire";

if (!inv_has('cavalier')) {
    $page_locked = true;
    $lock_msg = 'La Tour Noire est fermée par une énigme de mouvement gravée dans la porte : « Je ne marche pas en ligne droite. Je ne marche pas en diagonale. Apportez-moi celui qui sait comment avancer dans l\'ombre. » Le Cavalier Brisé saurait peut-être.';
    return;
}

if (!inv_has('cle_serveur') && !flag_has('cle_depuis_tour')) {
    inv_add('cle_serveur');
    flag_set('cle_depuis_tour');
    $notifs[] = ['icon' => '🔑', 'msg' => 'Au sommet de la Tour, gravée dans le mur comme si elle avait toujours été là : une <strong>Clé de Serveur</strong>. Elle vous attendait.'];
    secret_found();
}

ob_start(); ?>
<p>La Tour Noire est un paradoxe architectural. Elle monte verticalement à travers des couches de réalité qui ne devraient pas coexister — métal industriel rouillé, code binaire flottant à l'état solide, pierre médiévale taillée par des algorithmes, câbles de fibre optique qui pulsent comme des veines. Elle traverse tout le Nexus comme une colonne vertébrale dont personne ne voulait admettre l'existence.</p>

<p>À chaque palier, une pièce d'échecs géante vous barre le passage. Des fous. Des tours. Des pions. Chacun scellé par un pattern de mouvement différent.</p>

<p>Avec le <strong>Cavalier Brisé</strong>, vous trouvez à chaque fois le passage — le chemin en L, le seul mouvement que les autres pièces ne peuvent pas anticiper parce qu'il ne suit pas de logique linéaire. Le Cavalier ne va pas là où on l'attend. C'est pour ça qu'il survit.</p>

<p>Au sommet : une salle ronde, vide, avec un seul mot gravé en 47 langues sur les murs en cercle. Vous ne lisez que le français :</p>

<blockquote>« Le Roi ne perd jamais. Il abandonne simplement. »</blockquote>

<p>Et sous l'inscription, accrochée à un crochet de métal planté dans la pierre comme si quelqu'un avait décidé que <em>c'est ici que ça devait être</em> — la <strong>Clé de Serveur</strong>. Une clé taillée dans un métal qui n'existe pas dans les specs officielles du Nexus.</p>

<p>Sur la tige, gravé à la pointe : <strong>ARIA — TOUJOURS LÀ</strong>.</p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🖥️ Descendre vers la Chambre des Serveurs', 'page' => '014'],
    ['text' => '🃏 Chercher Le Fol (si vous avez le Joker)', 'page' => '011'],
    ['text' => '↩ Redescendre vers le Tableau', 'page' => '003'],
];