<?php
/* ── LE MARCHÉ DE L'OMBRE ── */
$page_title = "Le Marché de l'Ombre";

ob_start(); ?>
<p>Une place de marché souterraine éclairée par des hologrammes défaillants — certains affichent des prix en devises qui n'existent plus, d'autres projettent des visages de gens qui sont morts dans des boucles précédentes. Personne ne se regarde dans les yeux ici. C'est une règle non écrite.</p>

<p>Un marchand en manteau de données — une silhouette plus que un corps — vous interpelle depuis son étal :</p>

<blockquote>« Vous cherchez quelque chose de spécifique ? Ou juste à survivre jusqu'à la prochaine mort ? C'est pareil, finalement. Tout le monde ici cherche la même sortie. »</blockquote>

<p>Deux choses attirent votre attention dans l'obscurité du marché.</p>

<p>À droite : une <strong>table de jeu de cartes</strong>. Une silhouette en velours noir, dos tourné, bat un paquet. Le bruit des cartes ressemble à des données qui se fragmentent.</p>

<p>À gauche : dans un coin, un <strong>amas de câbles et de métal</strong> qui bouge parfois — qui murmure des coordonnées en boucle dans un registre trop haut pour être vraiment entendu. Une IA. Ce qui reste d'une IA.</p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🃏 S\'approcher de la table de jeu de cartes', 'page' => '009'],
    ['text' => '💾 Examiner l\'IA effondrée dans le coin', 'page' => '010'],
    ['text' => '↩ Retourner à la Bibliothèque', 'page' => '006'],
];