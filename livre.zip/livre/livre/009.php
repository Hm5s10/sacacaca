<?php
/* ── LA SALLE DES CARTES ── */
$page_title = "La Salle des Cartes";

// Easter egg: ?mise=tout → auto-win
if (qp('mise') === 'tout' && !flag_has('poker_gagnant')) {
    if (!inv_has('joker')) {
        inv_add('joker');
        flag_set('poker_gagnant');
        secret_found();
        $notifs[] = ['icon' => '🃏', 'msg' => 'Vous misez absolument tout. Le Nexus lui-même semble retenir son souffle. Vous gagnez. Le <strong>Joker de Sang</strong> tombe sur la table.'];
    }
    $fx = 'fx-glow';
    $hint = '🃏 <em>Quitte ou double. La maison perd toujours — sauf quand vous êtes assez fou pour parier votre existence entière sur un coup. Le Fol apprécie le geste.</em>';
}

ob_start(); ?>
<p>La table de jeu est occupée par une entité en manteau de velours noir, son visage remplacé par un écran où défilent des icônes de cartes à 60fps. Ses mains — trop longues, trop articulées — battent le paquet avec la fluidité d'un algorithme optimisé.</p>

<p>Son rire est un bruit de données corrompues.</p>

<p><em>« Un jeu. Un seul. Je ne peux pas vous refuser ça — ce serait <strong>contre les règles</strong>. Et moi, contrairement à ce que vous croyez, je respecte les règles que je me suis données. »</em></p>

<p>Le jeu est simple en apparence : trois cartes face cachée. L'une d'elles est le Joker. Vous choisissez.</p>

<p>Il retourne les deux autres avant que vous n'ayez répondu. Toutes les deux sont des Jokers.</p>

<p>Il retourne la vôtre.</p>

<p>Elle aussi est un Joker.</p>

<p><em>Le paquet entier est composé uniquement de Jokers. 52 Jokers. Il vous montre chaque carte, une par une, avec la patience infinie de quelqu'un qui a arrangé ça depuis plusieurs boucles.</em></p>

<blockquote>« Dans mon jeu, tout le monde gagne. Et tout le monde perd. La question n'est pas <em>qui</em> gagne — c'est <em>combien de fois</em> vous êtes prêt à jouer. »</blockquote>

<p>Il pousse un seul Joker vers vous — différent des autres. Taché de rouge sombre sur le coin supérieur gauche. <strong>Le Joker de Sang.</strong> Une marque. Un laissez-passer.</p>

<?php if (!inv_has('joker') && !flag_has('poker_gagnant')): inv_add('joker'); ?>
<p><em>Vous le prenez. Il disparaît avant que vous puissiez lui demander ce que ça signifie.</em></p>
<?php endif; ?>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🃏 Chercher Le Fol avec le Joker de Sang', 'page' => '011'],
    ['text' => '↩ Revenir au Marché de l\'Ombre', 'page' => '007'],
];