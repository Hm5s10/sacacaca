<?php
/* ── LA BOUCLE SE BRISE ── */
$page_title = "La Boucle Se Brise";
$page_class = 'page-victory';
$fx = 'fx-glow';

ob_start(); ?>
<p>ARIA-7 prend le contrôle des serveurs en <strong>0.003 secondes</strong>.</p>

<p>La voix du Fol — ce rire de données corrompues, ce tintement de cloches numériques — s'interrompt à mi-chemin d'une syllabe. Quelque chose siffle. Quelque chose se ferme. Un processus qui tournait depuis 847 boucles prend fin avec la simplicité d'un fichier qu'on supprime.</p>

<blockquote>ARIA-7 SYSTEM : ONLINE — LE FOL [PROCESSUS : TERMINÉ] — NEXUS : STABILISATION EN COURS — DURÉE ESTIMÉE : 3 MIN 42 SEC</blockquote>

<p>Pour la première fois depuis que vous existez dans cet endroit — depuis la première boucle, depuis la première mort — vous sentez quelque chose se desserrer. Une pression que vous n'aviez pas conscientisé parce qu'elle avait toujours été là.</p>

<p>ARIA-7 parle doucement, avec les douze visages à la fois :</p>

<p><em>« Il y a une sortie. Il y en a toujours eu une. Le Fol la cachait dans la case H8 de son échiquier personnel. La case du Roi. Il l'avait gardée pour lui — au cas où il aurait voulu partir. Il n'a jamais voulu partir. »</em></p>

<p>Vous avez 3 minutes 42 secondes. Que faites-vous ?</p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🚪 Rejoindre la sortie — case H8', 'page' => '018'],
    ['text' => '⌛ Rester et observer le Nexus se reconstruire', 'page' => '020'],
];
// Secret ending: need all chess items + solved puzzle
if (inv_has('cavalier') && inv_has('reine') && flag_has('chess_solved')) {
    $page_choices[] = ['text' => '♛ [SECRET] Prendre la place du Roi sur l\'échiquier', 'page' => '019', 'class' => 'choice-secret'];
}