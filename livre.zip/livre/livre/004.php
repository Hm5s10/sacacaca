<?php
/* ── LE COULOIR GLITCHÉ ── */
$page_title = "Le C̴o̸u̵l̵o̶i̷r̵ G̴l̵i̴t̵c̸h̵é̷";
$fx = 'fx-glitch';

// Easter egg: ?portail=echo → mirror room
if (qp('portail') === 'echo') {
    flag_set('echo_entendu');
    secret_found();
    $hint = '👁️ <em>Votre voix revient avec deux secondes de retard. Elle vient d\'une direction qui n\'a pas de nom sur les cartes du Nexus. Un couloir entre les couloirs.</em>';
    $notifs[] = ['icon' => '🪞', 'msg' => 'Vous suivez l\'écho. La réalité se plie légèrement.'];
    $page_choices = [
        ['text' => '🪞 [GLITCH] Suivre l\'écho vers l\'inconnu', 'page' => '023', 'class' => 'choice-secret'],
        ['text' => '↩ Rebrousser chemin rapidement', 'page' => '001'],
    ];
} else {
    $page_choices = [
        ['text' => '🌑 Continuer vers la Zone de Quarantaine', 'page' => '005'],
        ['text' => '↩ Rebrousser chemin', 'page' => '001'],
    ];
    if (flag_has('echo_entendu') || (int)flag_get('loop_count') >= 2) {
        $page_choices[] = ['text' => '💾 [BOUCLE] Parler à l\'écho de vous-même', 'page' => '010', 'class' => 'choice-secret'];
    }
}

ob_start(); ?>
<p>Le couloir ne devrait pas exister selon les plans du Nexus. Les murs se répètent — vous avez compté 47 portes identiques avant d'arrêter de compter. Le sol parfois n'est pas là : votre pied traverse une dalle comme si elle était fantôme, puis elle redevient solide. Parfois dans le mauvais sens.</p>

<p>Des <strong>fragments de données</strong> flottent dans l'air comme des confettis de mémoire :</p>

<blockquote>ERR_SECTOR_7F :: MEMORY_LEAK_DETECTED :: ZONE_ID=NULL :: OCCUPANT_COUNT=ERROR :: LAST_STABLE_STATE=BOUCLE_001</blockquote>

<p>Une silhouette court devant vous — votre propre silhouette, avec exactement deux secondes de retard. Un écho de vous-même coincé dans un buffer qui n'a jamais été vidé. Elle tourne à gauche. Il n'y a pas de gauche.</p>

<p><em>Vous entendez votre propre voix, en retard de deux secondes, dire quelque chose que vous n'avez pas encore dit.</em></p>
<?php
$page_content = ob_get_clean();