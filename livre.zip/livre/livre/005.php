<?php
/* ── LA ZONE DE QUARANTAINE ── */
$page_title = "La Zone de Quarantaine";

if (!inv_has('journal')) {
    inv_add('journal');
    $notifs[] = ['icon' => '📖', 'msg' => 'Dans les ruines d\'un campement de scavenger, vous trouvez un <strong>Journal Corrompu</strong>, à moitié brûlé.'];
}

ob_start(); ?>
<p>La Zone de Quarantaine ressemble aux images que vous n'avez jamais vues mais que vous reconnaissez quand même — comme si une mémoire d'emprunt avait été implantée dans votre tête au moment de votre spawn. Des ruines d'extraction, des drones tombés, des zones délimitées au spray rouge :</p>

<blockquote>ZONE CONTAMINÉE — PROTOCOLE CYCLE:FRONTIER ACTIF — DURÉE MAX D'EXPOSITION : 8 MIN — L'EXTRACTION N'EST PLUS GARANTIE</blockquote>

<p>Le sol est jonché de matériel abandonné. Des backpacks éventrés, du loot éparpillé, des traces de lutte que personne n'a eu le temps de fuir. Des scavengers ont vécu ici. Ont cherché à comprendre. N'ont pas réussi à extraire à temps.</p>

<p>Dans les décombres d'un campement, coincé sous un générateur renversé : un <strong>Journal Corrompu</strong> à moitié brûlé. Il a survécu à son propriétaire.</p>

<p>À l'horizon, la <strong>tempête de données</strong> pulse comme un organisme vivant — une muraille de code corrompu qui avance lentement, méthodiquement, vers votre position. Vous avez peu de temps avant qu'elle ne vous atteigne.</p>

<p><em>Dans la tempête, si vous regardez vraiment, vous croyez voir des silhouettes qui jouent aux cartes.</em></p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '📖 Trouver la Bibliothèque pour déchiffrer le journal', 'page' => '006'],
    ['text' => '🌑 S\'enfoncer dans la Zone (le Couloir Glitché)', 'page' => '004'],
    ['text' => '↩ Revenir au point de spawn', 'page' => '001'],
];