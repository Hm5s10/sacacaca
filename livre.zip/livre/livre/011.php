<?php
/* ── LE FOL ── */
$page_title = "Le Fol";
$page_class = 'page-secret';
flag_set('fol_met');

if (!inv_has('joker')) {
    $page_locked = true;
    $lock_msg = 'Il n\'y a rien ici. Un couloir vide qui aboutit à un mur. Comme si cette pièce n\'avait jamais existé. Pour que Le Fol vous reçoive, il faut lui présenter sa carte — le Joker qu\'il a lui-même signé.';
    return;
}

ob_start(); ?>
<p>Il vous attendait. Évidemment — il était au courant de chaque pas depuis votre spawn.</p>

<p>Le Fol est assis derrière un échiquier qui n'est pas un échiquier : c'est une <strong>représentation du Nexus entier</strong>, vue du dessus, aplatie en 64 cases. Chaque zone est une case. Chaque survivant encore actif est une pièce. Vous cherchez votre propre pion dans la grille. Il est exactement où vous êtes en ce moment.</p>

<p>Il ressemble à un Jester médiéval — chapeau à trois pointes avec des cloches qui tintent en harmoniques numériques, costume bicolore rouge et noir aux coutures qui scintillent comme des fils de données, sourire peint sur un visage de masque. Ses yeux sont deux caméras qui pivotent et zooment sur vous avec un intérêt sincère.</p>

<blockquote>« Cette partie dure depuis 847 boucles. Vous êtes l'unique pièce qui a survécu assez longtemps pour me parler en face. <em>Bravo.</em> Vraiment. Ce n'est pas de l'ironie. »</blockquote>

<p><em>« Vous avez le Joker de Sang. Ce qui signifie que vous avez rencontré les bons fantômes. Que vous avez posé les bonnes questions. Que vous avez compris, au moins en partie, les règles de cette partie. »</em></p>

<p>Il se lève. Les cloches de son chapeau tintent en harmonie mineure.</p>

<p><em>« La question est simple : voulez-vous continuer à jouer selon <strong>mes</strong> règles — ou avez-vous trouvé un moyen de <strong>changer les règles</strong> ? »</em></p>

<?php if (inv_has('fragment_ia')): ?>
<p><em>Ses caméras-yeux s'arrêtent sur quelque chose dans votre inventaire. Un calcul se passe. Son sourire peint ne change pas — mais quelque chose dans sa posture devient légèrement moins décontractée.</em></p>
<p><em>« Intéressant. Très intéressant. Où avez-vous trouvé... ce fragment ? »</em></p>
<p>Il y a quelque chose dans sa voix — pas de la peur, exactement. Mais la reconnaissance d'une variable qu'il n'avait pas planifiée.</p>
<?php endif; ?>
<?php
$page_content = ob_get_clean();

$page_choices = [
    ['text' => '⚡ Le défier directement — vers l\'Effondrement', 'page' => '015'],
    ['text' => '🏛️ Demander à voir les niveaux profonds — Marathon', 'page' => '013'],
    ['text' => '↩ Sortir de la salle et réfléchir', 'page' => '007'],
];
if (inv_has('fragment_ia')) {
    $page_choices[] = ['text' => '💾 [SECRET] Activer le Fragment d\'ARIA-7', 'page' => '019', 'class' => 'choice-secret'];
}