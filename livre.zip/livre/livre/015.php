<?php
/* ── L'EFFONDREMENT ── */
$page_title = "L'Effondrement";
$fx = 'fx-glitch';
$page_class = 'page-death';

flag_set('loop_count', (int)flag_get('loop_count') + 1);

ob_start(); ?>
<p>Le Nexus commence à se manger lui-même.</p>

<p>Les textures disparaissent par plaques — le sol, les murs, les plafonds — révélant le vide en dessous. Un vide qui n'est pas noir mais <strong>blanc</strong>, d'un blanc de page vierge qui fait mal aux yeux parce qu'il est trop propre, trop vide, trop honnête sur ce qu'est le Nexus quand on enlève le décor.</p>

<p>Les objets tombent vers le haut. Les sons arrivent avant leurs causes. Le Fol est quelque part dans ce chaos — vous l'entendez rire, son rire de données corrompues qui se fragmente en échos dans toutes les directions simultanément.</p>

<blockquote>ERR :: REALITY_BUFFER_OVERFLOW :: SECTOR_0x3F_CORRUPTED :: ALL_INSTANCES_WILL_BE_TERMINATED :: T-00:00:??</blockquote>

<p><em>« Vous voyez ? »</em> Sa voix arrive de partout et de nulle part. <em>« C'est ça, la vraie fin de partie. Pas un mat. Pas une victoire propre. Un <strong>abandon</strong>. La réalité qui dépose les armes. »</em></p>

<?php if (inv_has('cristal')): ?>
<p>Dans votre main, le <strong>Cristal de Boucle</strong> brûle d'une chaleur bleue. Il enregistre cet instant, cette configuration exacte du désastre. Si vous mourez ici — et les chances sont élevées — la prochaine boucle <em>saura</em>.</p>
<?php else: ?>
<p>Vous n'avez rien pour enregistrer cet instant. Si vous mourez ici, la prochaine boucle repart de presque zéro. <em>Presque.</em> La session garde les objets. Le Cristal aurait gardé autre chose.</p>
<?php endif; ?>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '💀 Vous laisser consumer par l\'Effondrement', 'page' => '025'],
    ['text' => '🏃 Courir vers le cœur du système', 'page' => '016'],
];
if (inv_has('cle_serveur') && inv_has('fragment_ia')) {
    $page_choices[] = ['text' => '🖥️ Sprint vers les Serveurs', 'page' => '014'];
}