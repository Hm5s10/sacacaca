<?php
/* ── L'ARÈNE DES DÉCOMBRES ── */
$page_title = "L'Arène des Décombres";

if (!inv_has('fusil')) {
    inv_add('fusil');
    $notifs[] = ['icon' => '🔫', 'msg' => 'Vous avez récupéré un <strong>Fusil UT-99</strong> coincé sous une poutrelle. Chargeur intact.'];
}

ob_start(); ?>
<p>L'Arène ressemble à ce qu'elle a toujours été — et à ce qu'elle n'aurait jamais dû devenir. Les gradins qui accueillaient autrefois des milliers de spectateurs virtuels sont effondrés, les drapeaux de capture de territoire pendant comme des peaux mortes sur leurs mâts rouillés.</p>

<p>Un texte en rouge sang est encore projeté sur le mur d'honneur, pixel par pixel, inlassablement :</p>

<blockquote>UNREAL TOURNAMENT — NEXUS CIRCUIT — SAISON 7 — ANNULÉE — RAISON : EXTINCTION DE MASSE</blockquote>

<p>Ce n'est pas une métaphore. C'est un log d'erreur.</p>

<p>Quelque chose bouge dans les décombres — plusieurs choses. Les <strong>Décimés</strong> : des corps qui ont refusé de se déconnecter quand le Nexus a glitché, et qui rejouent indéfiniment leurs derniers scripts de combat. Ils courent en pattern. Ils cherchent des ennemis. Ils en trouveront un.</p>

<p>Vous. À moins que vous n'ayez quelque chose pour les arrêter d'abord.</p>

<p>En levant les yeux vers la mezzanine, vous apercevez deux sorties : l'une mène vers les zones souterraines où rugissent les Décimés, l'autre vers une salle de tournoi dont l'hologramme d'entrée clignote encore faiblement — <em>REGISTER HERE — ALL SKILL LEVELS WELCOME</em>.</p>
<?php
$page_content = ob_get_clean();
$page_choices = [
    ['text' => '🧟 Descendre dans la zone infestée', 'page' => '008'],
    ['text' => '🏆 Explorer la salle de tournoi', 'page' => '022'],
    ['text' => '↩ Revenir au point de spawn', 'page' => '001'],
];