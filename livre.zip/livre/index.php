<?php
session_start();

/* ╔══════════════════════════════════════════════════════════════╗
   ║         LE SANCTUAIRE MAUDIT — Moteur de jeu v1.0          ║
   ╚══════════════════════════════════════════════════════════════╝ */

// ── Réinitialisation ─────────────────────────────────────────────────────────
if (isset($_GET['reset'])) { session_destroy(); header('Location: ?'); exit; }

// ── Session ───────────────────────────────────────────────────────────────────
foreach (['inventory','visited','flags','secrets'] as $k)
    if (!isset($_SESSION[$k])) $_SESSION[$k] = ($k==='secrets') ? 0 : [];

// ── Helpers ───────────────────────────────────────────────────────────────────
function inv_add($i)  { if (!in_array($i,$_SESSION['inventory'])) { $_SESSION['inventory'][]=$i; } }
function inv_has($i)  { return in_array($i, $_SESSION['inventory']??[]); }
function inv_rm($i)   { $_SESSION['inventory']=array_values(array_filter($_SESSION['inventory']??[],fn($x)=>$x!==$i)); }
function flag_set($f, $v=true) { $_SESSION['flags'][$f]=$v; }
function flag_get($f)          { return $_SESSION['flags'][$f]??null; }
function flag_has($f)          { return !empty($_SESSION['flags'][$f]); }
function visited($p)           { return !empty($_SESSION['visited'][$p]); }
function qp($k)                { return isset($_GET[$k]) ? trim((string)$_GET[$k]) : null; }
function secret_found()        { $_SESSION['secrets']++; }

// ── Routing ───────────────────────────────────────────────────────────────────
$page = preg_replace('/[^a-z0-9_-]/i','', $_GET['page']??'001');
$_SESSION['visited'][$page] = ($_SESSION['visited'][$page]??0)+1;

// ── Easter egg global : ?help=cheat ──────────────────────────────────────────
$show_cheatsheet = (qp('help') === 'cheat');

// ── Items ─────────────────────────────────────────────────────────────────────
$ITEMS = [
    'fusil'       => ['🔫','Fusil UT-99',          'Arme de l\'Arène. Efficace contre les Décimés.'],
    'reine'       => ['♛', 'La Reine Noire',       'Pièce d\'échecs en obsidienne. L\'enjeu ultime.'],
    'joker'       => ['🃏','Le Joker de Sang',      'Carte tachée de rouge. Le Fol l\'acceptera.'],
    'journal'     => ['📖','Journal Corrompu',      'Notes d\'un scavenger disparu dans la Zone.'],
    'cristal'     => ['🔵','Cristal de Boucle',     'Contient les souvenirs de vos morts passées.'],
    'fragment_ia' => ['💾','Fragment d\'ARIA-7',    'Mémoire d\'une IA déchue. Elle peut encore aider.'],
    'badge'       => ['🏷️', 'Badge NEXUS-7',        'Laissez-passer pour les niveaux profonds.'],
    'cavalier'    => ['♞', 'Le Cavalier Brisé',    'Pièce d\'échecs cassée. Se déplace en L.'],
    'cle_serveur' => ['🔑','Clé de Serveur',        'Accès à la Chambre des Serveurs centraux.'],
];

// ── Défauts de la page ────────────────────────────────────────────────────────
$page_title   = '§ '.$page;
$page_content = '';
$page_choices = [];
$page_locked  = false;
$lock_msg     = 'Ce passage est scellé par une magie très ancienne.';
$page_class   = '';
$notifs       = []; // [['icon'=>'🔦','msg'=>'...']]
$fx           = ''; // fx-glow fx-glitch fx-shake fx-dark fx-rain fx-blood
$hint         = null;

// ── Parser Markdown ───────────────────────────────────────────────────────────
function imd($s) {
    $s = htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    $s = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $s);
    $s = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $s);
    $s = preg_replace('/_(.+?)_/', '<em>$1</em>', $s);
    $s = preg_replace('/`(.+?)`/', '<code>$1</code>', $s);
    return $s;
}
function parse_md($md) {
    $title=$html=$buf=''; $choices=[];
    $flush = function() use (&$buf,&$html) {
        $t=trim($buf); if($t) $html.='<p>'.imd($t)."</p>\n"; $buf='';
    };
    foreach (explode("\n",$md) as $raw) {
        $l = rtrim($raw);
        if (preg_match('/^# (.+)$/',$l,$m))  { $flush(); $title=trim($m[1]); continue; }
        if (preg_match('/^## (.+)$/',$l,$m)) { $flush(); $html.='<h2>'.imd($m[1])."</h2>\n"; continue; }
        if (preg_match('/^### (.+)$/',$l,$m)){ $flush(); $html.='<h3>'.imd($m[1])."</h3>\n"; continue; }
        if (preg_match('/^-{3,}\s*$/',$l))   { $flush(); $html.="<hr>\n"; continue; }
        if (preg_match('/^> (.+)$/',$l,$m))  { $flush(); $html.='<blockquote>'.imd($m[1])."</blockquote>\n"; continue; }
        if (preg_match('/^- \[(.+?)\]\(([a-z0-9_-]+)\)/i',$l,$m)) {
            $flush(); $choices[]=['text'=>$m[1],'page'=>$m[2]]; continue;
        }
        if (trim($l)==='') { $flush(); continue; }
        $buf .= ($buf?' ':'').$l;
    }
    $flush();
    return ['title'=>$title,'html'=>$html,'choices'=>$choices];
}

// ── Chargement de la page ─────────────────────────────────────────────────────
$php_f = __DIR__."/livre/{$page}.php";
$md_f  = __DIR__."/livre/{$page}.md";

if (file_exists($php_f)) {
    ob_start(); include $php_f; $ob = ob_get_clean();
    if ($ob && !$page_content) $page_content = $ob;
} elseif (file_exists($md_f)) {
    $r = parse_md(file_get_contents($md_f));
    $page_title   = $r['title'] ?: $page_title;
    $page_content = $r['html'];
    $page_choices = $r['choices'];
} else {
    $page_title   = '— Page Perdue —';
    $page_content = '<p>Ces pages ont été dévorées par l\'obscurité. Ce passage n\'existe pas dans le Sanctuaire.</p>';
    $page_choices = [['text'=>'↩ Retourner à l\'entrée','page'=>'001']];
}

// ── Mode cheatsheet ───────────────────────────────────────────────────────────
if ($show_cheatsheet) {
    $page_title   = '— Grimoire des Secrets —';
    $page_class   = 'page-secret';
    $fx           = 'fx-glow';
    $page_choices = [['text'=>'↩ Refermer le grimoire','page'=>$_GET['page']??'001']];
    $page_content = <<<HTML
<p><em>Vous avez trouvé le Grimoire des Secrets. Ces connaissances ne devraient pas exister...</em></p>
<h2>✦ Easter Eggs du Sanctuaire</h2>
<blockquote><strong>Page 001 :</strong> Ajoutez <code>?rune=fehu</code> pour invoquer l'Amulette Runique. Effet visuel : lueur dorée.</blockquote>
<blockquote><strong>Page 001 :</strong> Ajoutez <code>?portail=yggdrasil</code> pour ouvrir un passage secret vers la fin véritable.</blockquote>
<blockquote><strong>Page 004 :</strong> Ajoutez <code>?grimoire=open</code> pour lire un grimoire scellé et obtenir un indice crucial.</blockquote>
<blockquote><strong>Page 005 :</strong> Ajoutez <code>?coffre=miroir</code> pour révéler le double fond d'un coffre grâce à un miroir brisé.</blockquote>
<blockquote><strong>Page 006 :</strong> Ajoutez <code>?gardien=endors</code> pour endormir le Gardien de Pierre sans combat.</blockquote>
<blockquote><strong>Partout :</strong> Le Code Konami (↑↑↓↓←→←→BA) déclenche un effet secret...</blockquote>
<blockquote><strong>Partout :</strong> <code>?help=cheat</code> affiche ce grimoire (vous y êtes).</blockquote>
<h2>✦ Objets &amp; Déverrouillages</h2>
<blockquote>La <strong>Clé Rouillée</strong> n'apparaît dans l'Alcôve (004) que si vous portez l'Amulette.</blockquote>
<blockquote>La <strong>Carte Secrète</strong> s'obtient dans l'Armurerie (005) en ouvrant le coffre avec la Clé.</blockquote>
<blockquote>Le <strong>Fragment du Nexus</strong> se trouve via l'easter egg du miroir dans l'Armurerie.</blockquote>
<blockquote>La <strong>Carte Secrète</strong> déverrouille la Fin Secrète depuis la Salle du Trésor.</blockquote>
HTML;
}

// ── Helper rendu de lien de choix ─────────────────────────────────────────────
function choice_href($c) {
    if (isset($c['href'])) return htmlspecialchars($c['href']);
    $h = '?page='.htmlspecialchars($c['page']??'001');
    if (!empty($c['params'])) foreach ($c['params'] as $k=>$v) $h.='&'.urlencode($k).'='.urlencode($v);
    return $h;
}

// ── Compte les secrets trouvés ────────────────────────────────────────────────
$secrets_count = $_SESSION['secrets']??0;
$total_secrets = 7;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Le Sanctuaire Maudit · <?= htmlspecialchars($page_title) ?></title>
<style>
/* ── Reset ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { font-size: 16px; scroll-behavior: smooth; }

/* ── Variables ── */
:root {
    --bg:       #080810;
    --surface:  #111119;
    --surface2: #191926;
    --border:   #27273d;
    --gold:     #c9a84c;
    --gold-dim: #7a6330;
    --blood:    #8b1a1a;
    --blood-dim:#4a0d0d;
    --text:     #c8b89a;
    --text-dim: #5a5040;
    --text-hi:  #e8d8b8;
    --purple:   #9060c0;
    --glow-gold:rgba(201,168,76,0.25);
    --glow-blood:rgba(139,26,26,0.25);
    --glow-purple:rgba(144,96,192,0.25);
}

/* ── Body ── */
body {
    background-color: var(--bg);
    background-image:
        radial-gradient(ellipse at 15% 85%, rgba(30,10,60,0.6) 0%, transparent 55%),
        radial-gradient(ellipse at 85% 15%, rgba(70,20,10,0.4) 0%, transparent 55%);
    color: var(--text);
    font-family: 'Georgia','Times New Roman',serif;
    min-height: 100vh;
    transition: filter 0.8s;
}

/* ── Layout ── */
.wrapper {
    display: flex;
    min-height: 100vh;
    max-width: 1120px;
    margin: 0 auto;
}

/* ── Sidebar ── */
.sidebar {
    width: 210px;
    min-width: 210px;
    background: var(--surface);
    border-right: 1px solid var(--border);
    padding: 1.5rem 1rem;
    display: flex;
    flex-direction: column;
    position: sticky;
    top: 0;
    height: 100vh;
    overflow-y: auto;
}
.sidebar-logo {
    text-align: center;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--border);
    margin-bottom: 1rem;
}
.sidebar-logo .skull { font-size: 1.4rem; }
.sidebar-logo h2 {
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.18em;
    color: var(--gold);
    margin-top: 0.3rem;
}
.inv-title {
    font-size: 0.65rem;
    text-transform: uppercase;
    letter-spacing: 0.2em;
    color: var(--text-dim);
    margin-bottom: 0.6rem;
}
.inv-empty {
    font-style: italic;
    font-size: 0.78rem;
    color: var(--text-dim);
    text-align: center;
    padding: 0.8rem 0;
    border: 1px dashed var(--border);
    border-radius: 3px;
}
.inv-item {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
    padding: 0.45rem 0.5rem;
    border-radius: 4px;
    margin-bottom: 0.35rem;
    background: var(--surface2);
    border: 1px solid var(--border);
    position: relative;
    cursor: help;
    transition: border-color 0.2s, box-shadow 0.2s;
    animation: itemAppear 0.4s ease;
}
@keyframes itemAppear {
    from { opacity:0; transform:translateX(-8px); }
    to   { opacity:1; transform:translateX(0); }
}
.inv-item:hover { border-color: var(--gold); box-shadow: 0 0 8px var(--glow-gold); }
.inv-item:hover .inv-tooltip { opacity:1; pointer-events:none; }
.inv-icon { font-size: 1rem; flex-shrink:0; margin-top:1px; }
.inv-info { display:flex; flex-direction:column; }
.inv-label { font-size: 0.75rem; color: var(--text-hi); font-weight: bold; line-height:1.2; }
.inv-desc  { font-size: 0.65rem; color: var(--text-dim); margin-top:1px; font-style:italic; line-height:1.3; }
.inv-tooltip {
    position: absolute;
    left: 105%; top: 0;
    background: var(--surface2);
    border: 1px solid var(--gold);
    padding: 0.35rem 0.6rem;
    font-size: 0.72rem;
    white-space: nowrap;
    z-index: 20;
    color: var(--text);
    border-radius: 3px;
    opacity: 0;
    transition: opacity 0.15s;
    pointer-events: none;
}

/* Sidebar footer */
.sidebar-sep { border:none; border-top:1px solid var(--border); margin: 1rem 0 0.8rem; }
.sidebar-footer { margin-top: auto; }
.page-badge {
    font-family: monospace;
    font-size: 0.65rem;
    color: var(--text-dim);
    text-align: center;
    margin-bottom: 0.6rem;
    letter-spacing: 0.1em;
}
.secrets-badge {
    font-size: 0.65rem;
    color: var(--purple);
    text-align: center;
    margin-bottom: 0.7rem;
    letter-spacing: 0.05em;
}
.btn-reset {
    display: block;
    padding: 0.4rem;
    background: var(--blood-dim);
    border: 1px solid var(--blood);
    color: #c0a0a0;
    font-size: 0.72rem;
    text-decoration: none;
    border-radius: 3px;
    text-align: center;
    transition: background 0.2s, color 0.2s;
    font-family: Georgia, serif;
    letter-spacing: 0.05em;
}
.btn-reset:hover { background: var(--blood); color: #fff; }

/* ── Livre principal ── */
.book {
    flex: 1;
    padding: 2.5rem 3.5rem 3rem;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    background-image:
        repeating-linear-gradient(
            0deg, transparent, transparent 30px,
            rgba(255,255,255,0.012) 30px, rgba(255,255,255,0.012) 31px
        );
}

/* Book header */
.book-header {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1.2rem;
    padding-bottom: 1.2rem;
    border-bottom: 1px solid var(--border);
    margin-bottom: 2.5rem;
}
.book-header h1 {
    font-size: 1rem;
    letter-spacing: 0.25em;
    text-transform: uppercase;
    color: var(--gold);
    white-space: nowrap;
    font-weight: normal;
}
.ornament { color: var(--gold-dim); font-size: 1.3rem; }

/* Chapter header */
.ch-header {
    display: flex;
    align-items: baseline;
    gap: 1rem;
    margin-bottom: 2rem;
    border-bottom: 1px solid var(--border);
    padding-bottom: 1rem;
}
.ch-num {
    font-family: monospace;
    font-size: 0.72rem;
    color: var(--text-dim);
    letter-spacing: 0.12em;
    white-space: nowrap;
    padding-top: 0.2rem;
}
.ch-title {
    font-size: 1.6rem;
    color: var(--text-hi);
    font-weight: normal;
    line-height: 1.2;
    flex:1;
}

/* Prose */
.prose { line-height: 1.85; font-size: 1.05rem; }
.prose p          { margin-bottom: 1.1em; }
.prose h2         { color: var(--gold); font-size: 1.05rem; font-weight:bold; margin: 1.5em 0 0.6em; text-transform: uppercase; letter-spacing: 0.1em; }
.prose h3         { color: var(--text); font-size: 1rem; margin: 1em 0 0.4em; }
.prose hr         { border: none; border-top: 1px solid var(--border); margin: 1.8em 0; }
.prose strong     { color: var(--text-hi); }
.prose em         { color: #9a8870; font-style: italic; }
.prose blockquote {
    border-left: 3px solid var(--blood);
    padding: 0.6em 1.1em;
    margin: 1.2em 0;
    background: rgba(139,26,26,0.08);
    color: #a08070;
    font-style: italic;
    border-radius: 0 4px 4px 0;
}
.prose code {
    font-family: monospace;
    background: var(--surface2);
    padding: 0.1em 0.4em;
    border-radius: 3px;
    font-size: 0.88em;
    color: var(--gold);
    border: 1px solid var(--border);
}

/* Notifications */
.notifs { display:flex; flex-direction:column; gap:0.5rem; margin-bottom: 1.8rem; }
.notif {
    padding: 0.65rem 1rem;
    background: rgba(201,168,76,0.1);
    border: 1px solid rgba(201,168,76,0.35);
    border-radius: 5px;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 0.6rem;
    animation: slideDown 0.4s ease;
}
.notif-icon { font-size: 1.1rem; flex-shrink:0; }
@keyframes slideDown {
    from { opacity:0; transform:translateY(-10px); }
    to   { opacity:1; transform:translateY(0); }
}

/* Hint box */
.hint-box {
    padding: 0.8rem 1.1rem;
    background: rgba(144,96,192,0.1);
    border: 1px solid rgba(144,96,192,0.35);
    border-radius: 5px;
    font-size: 0.9rem;
    margin-bottom: 1.8rem;
    color: #c0a0e0;
    font-style: italic;
    line-height: 1.6;
}
.hint-box code { color: #e0c0ff; }

/* Choices */
.choices { margin-top: 2.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border); display:flex; flex-direction:column; gap:0.65rem; }
.choices-label { font-size:0.68rem; text-transform:uppercase; letter-spacing:0.2em; color:var(--text-dim); margin-bottom:0.3rem; }
.btn-choice {
    display: flex;
    align-items: center;
    gap: 0.8rem;
    padding: 0.85rem 1.2rem;
    background: var(--surface);
    border: 1px solid var(--border);
    color: var(--text);
    text-decoration: none;
    border-radius: 5px;
    font-size: 0.95rem;
    font-family: Georgia, serif;
    transition: border-color 0.2s, background 0.2s, color 0.2s, transform 0.15s, box-shadow 0.2s;
    position: relative;
}
.btn-choice:hover {
    border-color: var(--gold);
    color: var(--text-hi);
    background: var(--surface2);
    transform: translateX(5px);
    box-shadow: -3px 0 0 var(--gold);
}
.btn-choice.choice-visited { opacity: 0.7; }
.btn-choice.choice-visited::after {
    content: '✓';
    margin-left: auto;
    color: var(--text-dim);
    font-size: 0.75rem;
    flex-shrink:0;
}
.choice-arr { color: var(--blood); font-size: 1rem; flex-shrink:0; }
.choice-secret { border-color: rgba(144,96,192,0.4); color: #c0a0e0; }
.choice-secret:hover { border-color: var(--purple); box-shadow: -3px 0 0 var(--purple); }
.choice-secret .choice-arr { color: var(--purple); }
.choice-death { border-color: rgba(139,26,26,0.4); }
.choice-death:hover { border-color: var(--blood); box-shadow: -3px 0 0 var(--blood); }

/* Page verrouillée */
.locked { text-align:center; padding:3rem 2rem; display:flex; flex-direction:column; align-items:center; gap:1.2rem; }
.lock-icon { font-size:3rem; animation: pulse 2s ease-in-out infinite; }
@keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.08)} }
.lock-msg { color: var(--blood); font-size:1.1rem; line-height:1.6; }
.lock-hint { font-size:0.85rem; color:var(--text-dim); font-style:italic; }

/* Book footer */
.book-footer {
    margin-top: auto;
    padding-top: 2rem;
    border-top: 1px solid var(--border);
    text-align: center;
    font-size: 0.7rem;
    color: var(--border);
    letter-spacing: 0.25em;
    text-transform: uppercase;
}

/* ── Thèmes de page ── */
.page-death .ch-title { color: var(--blood); }
.page-death .prose blockquote { border-color: #600; background: rgba(100,0,0,0.1); }
.page-death .btn-choice { border-color: rgba(139,26,26,0.3); }

.page-victory .ch-title { color: var(--gold); }
.page-victory .book { background-image: repeating-linear-gradient(0deg,transparent,transparent 30px,rgba(201,168,76,0.015) 30px,rgba(201,168,76,0.015) 31px); }

.page-secret .ch-title { color: #c0a0e0; }
.page-secret .book { background-image: repeating-linear-gradient(0deg,transparent,transparent 30px,rgba(144,96,192,0.015) 30px,rgba(144,96,192,0.015) 31px); }
.page-secret .ornament { color: rgba(144,96,192,0.5); }

/* ── Effets spéciaux ── */
.fx-glow { animation: globalGlow 2.5s ease-out; }
@keyframes globalGlow { 0%{filter:brightness(1)} 40%{filter:brightness(1.4) saturate(1.5)} 100%{filter:brightness(1)} }

.fx-glitch .book { animation: glitch 0.15s steps(1) 0s 12 alternate; }
@keyframes glitch { 0%{transform:translate(0)} 20%{transform:translate(-3px,2px)} 40%{transform:translate(3px,-2px);filter:hue-rotate(20deg)} 60%{transform:translate(-2px,1px)} 80%{transform:translate(2px,-1px)} 100%{transform:translate(0)} }

.fx-shake { animation: shake 0.6s ease-out; }
@keyframes shake { 0%,100%{transform:translate(0)} 15%{transform:translate(-6px,3px)} 30%{transform:translate(6px,-4px)} 45%{transform:translate(-4px,2px)} 60%{transform:translate(4px,-2px)} 75%{transform:translate(-2px,1px)} 90%{transform:translate(1px,-1px)} }

.fx-dark .prose { color: #1a1220; text-shadow: 0 0 10px rgba(200,184,154,0.9); }
.fx-dark .prose:hover { color: var(--text); text-shadow: none; }

.fx-blood { animation: bloodFlash 1.5s ease-out; }
@keyframes bloodFlash { 0%{filter:brightness(1)} 20%{filter:brightness(0.6) sepia(1) saturate(3) hue-rotate(-20deg)} 100%{filter:brightness(1)} }

/* Rain overlay */
#rain { position:fixed; inset:0; pointer-events:none; z-index:500; display:none; overflow:hidden; }
.fx-rain #rain { display:block; }

/* Toast */
#toast {
    position: fixed;
    bottom: 2rem;
    left: 50%;
    transform: translateX(-50%) translateY(100px);
    background: var(--surface2);
    border: 1px solid var(--gold);
    color: var(--text);
    padding: 0.7rem 1.5rem;
    border-radius: 5px;
    font-family: Georgia, serif;
    font-size: 0.9rem;
    z-index: 9999;
    transition: transform 0.4s ease, opacity 0.4s;
    opacity: 0;
    max-width: 400px;
    text-align: center;
    line-height: 1.5;
}
#toast.visible { transform: translateX(-50%) translateY(0); opacity: 1; }
</style>
</head>
<body class="<?= htmlspecialchars(trim($page_class.' '.$fx)) ?>">

<div id="rain"></div>
<div id="toast"></div>

<div class="wrapper">

  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="skull">☠</div>
      <h2>Le Sanctuaire Maudit</h2>
    </div>

    <div class="inv-title">⚔ Inventaire</div>

    <?php if (empty($_SESSION['inventory'])): ?>
    <div class="inv-empty">Rien pour le moment...</div>
    <?php else: ?>
    <?php foreach ($_SESSION['inventory'] as $item):
        $cfg = $ITEMS[$item] ?? ['?','???','Objet inconnu'];
    ?>
    <div class="inv-item" title="<?= htmlspecialchars($cfg[2]) ?>">
      <span class="inv-icon"><?= $cfg[0] ?></span>
      <div class="inv-info">
        <span class="inv-label"><?= htmlspecialchars($cfg[1]) ?></span>
        <span class="inv-desc"><?= htmlspecialchars($cfg[2]) ?></span>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <hr class="sidebar-sep">

    <div class="sidebar-footer">
      <div class="page-badge">Page <?= htmlspecialchars($page) ?> · <?= count($_SESSION['visited']) ?> visitées</div>
      <?php if ($secrets_count > 0): ?>
      <div class="secrets-badge">✦ <?= $secrets_count ?>/<?= $total_secrets ?> secrets découverts</div>
      <?php endif; ?>
      <a href="?reset=1" class="btn-reset" onclick="return confirm('Recommencer depuis le début ?')">✦ Recommencer</a>
    </div>
  </aside>

  <!-- ── Livre ── -->
  <main class="book">

    <div class="book-header">
      <span class="ornament">❧</span>
      <h1>Le Sanctuaire Maudit</h1>
      <span class="ornament">❧</span>
    </div>

    <?php if (!empty($notifs)): ?>
    <div class="notifs">
      <?php foreach ($notifs as $n): ?>
      <div class="notif">
        <span class="notif-icon"><?= $n['icon'] ?></span>
        <span><?= $n['msg'] ?></span>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ($hint): ?>
    <div class="hint-box"><?= $hint ?></div>
    <?php endif; ?>

    <article>
      <?php if ($page_locked): ?>
      <div class="locked">
        <span class="lock-icon">🔒</span>
        <p class="lock-msg"><?= htmlspecialchars($lock_msg) ?></p>
        <p class="lock-hint">Cherchez un autre chemin...</p>
        <a href="javascript:history.back()" class="btn-choice" style="margin-top:0.5rem">
          <span class="choice-arr">⟶</span> Faire demi-tour
        </a>
      </div>
      <?php else: ?>

      <div class="ch-header">
        <span class="ch-num">§&thinsp;<?= htmlspecialchars($page) ?></span>
        <h2 class="ch-title"><?= htmlspecialchars($page_title) ?></h2>
      </div>

      <div class="prose"><?= $page_content ?></div>

      <?php if (!empty($page_choices)): ?>
      <div class="choices">
        <div class="choices-label">Que faites-vous ?</div>
        <?php foreach ($page_choices as $c):
            $href = choice_href($c);
            $target = $c['page'] ?? '';
            $is_visited = $target && visited($target);
            $extra_class = '';
            if (!empty($c['class'])) $extra_class = ' '.$c['class'];
        ?>
        <a href="<?= $href ?>" class="btn-choice<?= $is_visited?' choice-visited':'' ?><?= $extra_class ?>">
          <span class="choice-arr">⟶</span>
          <?= htmlspecialchars($c['text']) ?>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php endif; ?>
    </article>

    <div class="book-footer">✦ &thinsp; Le Sanctuaire Maudit &thinsp; ✦</div>
  </main>

</div>

<script>
// ── Code Konami ───────────────────────────────────────────────────────────────
const KONAMI = [38,38,40,40,37,39,37,39,66,65];
let ki = 0;
document.addEventListener('keydown', e => {
    ki = (e.keyCode === KONAMI[ki]) ? ki+1 : (e.keyCode === KONAMI[0] ? 1 : 0);
    if (ki === KONAMI.length) {
        ki = 0;
        document.body.style.transition = 'filter 0.6s';
        document.body.style.filter = 'invert(1) hue-rotate(180deg)';
        toast('🌀 Le Sanctuaire vous reconnaît, Ancien...\n« L\'arbre-monde a de nombreuses branches. »');
        setTimeout(() => document.body.style.filter = '', 3500);
    }
});

// ── Rain effect ───────────────────────────────────────────────────────────────
if (document.body.className.includes('fx-rain')) {
    const rain = document.getElementById('rain');
    for (let i = 0; i < 80; i++) {
        const d = document.createElement('div');
        const h = Math.random()*50+15, delay = Math.random()*3, dur = Math.random()*0.8+0.4;
        d.style.cssText = `position:absolute;width:1px;height:${h}px;background:rgba(100,150,255,${Math.random()*0.35+0.1});left:${Math.random()*100}%;top:-${h}px;animation:rainDrop ${dur}s linear ${delay}s infinite`;
        rain.appendChild(d);
    }
    const s = document.createElement('style');
    s.textContent = '@keyframes rainDrop{from{transform:translateY(0)}to{transform:translateY(110vh)}}';
    document.head.appendChild(s);
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('visible');
    setTimeout(() => t.classList.remove('visible'), 4500);
}

// ── Auto-remove glitch ────────────────────────────────────────────────────────
if (document.body.className.includes('fx-glitch'))
    setTimeout(() => document.body.classList.remove('fx-glitch'), 2500);
</script>
</body>
</html>